from django.shortcuts import render

# Create your views here.

# @api_view(['POST'])
# @permission_classes([IsAuthenticated])
# def follow(request, user_pk):
#     User = get_user_model()
#     me = request.user
#     profile_user = User.objects.get(pk=user_pk)
#     if me != profile_user:
#         if profile_user.followers.filter(pk=me.pk).exists():
#             profile_user.followers.remove(me)
#             isFollowing = False
#         else:
#             profile_user.followers.add(me)
#             isFollowing = True
#         data = {
#             'isFollowing': isFollowing
#         }
#         return Response(data)