import Vue from 'vue'
import Vuex from 'vuex'
import axios from 'axios'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    movies: null,
  },
  getters: {
  },
  mutations: {
    GET_LATEST_MOVIES(state, movies){
      state.movies = movies
  },
},
actions: {
  getLatestMovies(context){  // API 호출해서 데이터 state에 넘겨주는 함수
    console.log('getLatestMovies (vuex)')
    const key_API = process.env.VUE_APP_KEY
  axios({
    method:'get',
    url:`https://api.themoviedb.org/3/movie/now_playing?api_key=${key_API}&language=ko-KR&page=1`
  })
  .then((res) => {
    context.commit('GET_LATEST_MOVIES', res.data)
  })
  },
},
  modules: {
  }
})
