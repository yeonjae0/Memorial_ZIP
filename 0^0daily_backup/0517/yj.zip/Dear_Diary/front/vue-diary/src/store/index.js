import Vue from 'vue'
import Vuex from 'vuex'
import axios from 'axios'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    movies: null,
  },
  getters: {
  },
  mutations: {
    GET_MOVIES(state, movies){
    console.log('GET_MOVIES')
      state.movies = movies
  },
},
actions: {
  getMovies(context){  // API 호출해서 데이터 state에 넘겨주는 함수
    console.log('getMovies (vuex)')
    const key_API = process.env.VUE_APP_KEY
  axios({
    method:'get',
    url:`https://api.themoviedb.org/3/movie/top_rated?api_key=${key_API}&language=ko-KR&page=1`
  })
  .then((res) => {
    context.commit('GET_MOVIES', res.data)
  })
  },
},
  modules: {
  }
})
