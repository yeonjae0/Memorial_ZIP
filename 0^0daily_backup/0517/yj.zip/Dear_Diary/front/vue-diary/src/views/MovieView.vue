<template>
  <div class="movie">
<!-- <img alt="Vue logo" src="../assets/logo.png"> -->

    <!-- {{ movieFn }} -->
    <div class="row row-cols-1 row-cols-md-3 g-2" >
    <MovieCard v-for="(movie, index) in movieFn" :key="index" :movie="movie"/>
    </div>
  </div>
</template>

<script>


import MovieCard from '@/components/MovieCard.vue'

export default {
  name: 'MovieView',
  components: {
    MovieCard
  },
  data(){
    return{
      // tmdbKey: null,
      // movieData: null,
    }
  },
  created() {
    this.getMovies()
    // console.log(this.$store.state.movies)
  },
  methods: {
    getMovies(){
      this.$store.dispatch('getMovies')
    }
  },
  computed: {
    movieFn(){
      return this.$store.state.movies?.results
    }
  }

}
</script>
<style>
</style>
